package bg.sofia.uni.fmi.mjt.fittrack.workout;

public enum WorkoutType {
    CARDIO, STRENGTH, YOGA
}